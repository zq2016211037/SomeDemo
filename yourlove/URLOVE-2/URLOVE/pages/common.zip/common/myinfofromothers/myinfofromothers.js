var userId,userToken;
var othersId;
Page({
	data:{
		userhead: "",
		username: "",
		userlevel: "Lv9",
		usersignature: "",
		releasenum: "",
		focusnum: "",
		fansnum: ""
	},
	onLoad:function(options){
		userToken = getApp().globalData.userToken;
    	userId = getApp().globalData.userId;
		othersId = options.topicuserId;
		this.getOthersInfo();
	},
	getOthersInfo: function(){
		var that = this;
	    wx.request({
	      url: 'http://120.78.165.40:9090/user/getUserInfo',
	      header: {
	        "Content-Type": "applciation/json",
	        "userToken": userToken,
	        "userId": userId
	      },
	      method: "GET",
	      data: {
	        userId: othersId,
	      },
	      success: function (res) {
	        console.log(res);
	        that.setData({
	        	userhead:res.data.data.avatarUrl,
	        	username:res.data.data.nickName,
	        	usersignature:res.data.data.signature,
	        	releasenum:res.data.data.publishedNum,
	        	focusnum:res.data.data.followNum,
	        	fansnum:res.data.data.fansNum
	        })
	      }

	    })
	}
	
})		