<template>
<div>
  <el-container class="allWrapper">
  <el-aside v-show="ifEnter" class="slider" style="width:250px"> <leftNav/></el-aside>
  <el-main><router-view class="other"></router-view></el-main>
</el-container>
</div>
</template>

<script>
import leftNav from '@/components/homeNav'
export default {
  name:'App',
  data(){
    return{
      ifEnter:false
    }
  },
  components:{
    leftNav
  },
  watch:{
    $route(to,from){
      if(to.path=="/"){
        this.ifEnter = false;
      }else{
        this.ifEnter = true;
      }
    }
  },
  mounted:function(){
    if(this.$route.path=="/"){
      this.ifEnter = false;
    }else{
      this.ifEnter = true;
    }
  }
}
</script>

<style scoped>
.allWrapper{
  height:100vh;
  overflow-x: hidden;
}
.slider{
  border-right:1px solid #cccccc;
}

</style>
