import Vue from 'vue'
import Router from 'vue-router'
import enter from '@/components/pages/enter'
import findUser from '@/components/pages/findUser'
import userInformation from '@/components/pages/userInformation'
import seeArticle from '@/components/pages/seeArticle'
import seeUser from '@/components/pages/seeUser'
import seePicture from '@/components/pages/seePicture'
import articleUser from '@/components/articleUser'
Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name:"enter",
      component:enter
    },{
      path:"/yourlove",
      name:"findUser",
      component:findUser
    },
    {
      path:"/userInfo",
      name:"userInformation",
      component:userInformation
    },
    {
      path:"/seeArticle",
      name:"seeAeticle",
      component:seeArticle
    },{
      path:"/seeUser",
      name:"seeUser",
      component:seeUser
    },{
      path:"/seePicture",
      name:"seePicture",
      component:seePicture
    },{
      path:"/articleDetail",
      name:"articleUser",
      component:articleUser
    }
  ]
})
