<template>
    <canvas id="canvas" class="myCanvas"/>
</template>
<script>
import init from "../assets/canvas/canvas.js"
export default {
    name:"myCanvas",
    mounted:function(){
        let canvas = document.getElementById('canvas');
        console.log(canvas);
        let ctx = canvas.getContext('2d');  
        let w = canvas.width = canvas.offsetWidth;
        let h = canvas.height = canvas.offsetHeight;
        let config = {
            ctx:ctx,
            w:w,
            h:h
        }
        console.log(config);
        init(120,config);
    }
}
</script>
<style scoped>
    .myCanvas{
        width:100%;
        height:100%;
        position: absolute;
        z-index:-1;
        top:0;
        left:0;
    }
</style>
