<template>
<div>
    <p>
        <img :src="info.avatarUrl"/>
        <span>{{info.nickName}}</span>
    </p>
</div>
</template>
<script>
export default {
    name:"userBar",
    data(){
        return{
            info:{
                avatarUrl:"http://loveimg.lengren.com.cn/1535051919356",
                nickName:"Innocent",
            }
        }
    }
}
</script>
<style scoped>
img{
    width:50px;
    height:50px;
    border-radius: 50%;
    border:1px solid #cccccc;
    vertical-align: middle
}
span{
    display: inline-block;
    vertical-align: middle;
    margin-left: 5px;
}
</style>
