<template>
    <div class="photoWrapper">
        <img :src="obj.url" />
        <div class="wordsWrapper">
            <h1>{{obj.title}}</h1>
            <el-upload  class="upload-demo"
  action="https://jsonplaceholder.typicode.com/posts/"
  :on-preview="handlePreview"
  :on-remove="handleRemove"
  :before-remove="beforeRemove"
  multiple
  :limit="3"
  :on-exceed="handleExceed"
  :file-list="fileList">
                <el-button size="small" type="primary">点击上传</el-button>
            </el-upload>
        </div>
    </div>
</template>
<script>
export default {
  name: "pictureItem",
  props: {
    obj: {
        url:"",
        title:""
    }
  },
  methods: {
    handleRemove(file, fileList) {
      console.log(file, fileList);
    },
    handlePreview(file) {
      console.log(file);
    },
    handleExceed(files, fileList) {
      this.$message.warning(
        `当前限制选择 3 个文件，本次选择了 ${
          files.length
        } 个文件，共选择了 ${files.length + fileList.length} 个文件`
      );
    },
    beforeRemove(file, fileList) {
      return this.$confirm(`确定移除 ${file.name}？`);
    }
  }
};
</script>
 <style scoped>
 .photoWrapper{
    margin:40px;
    display: flex;
 }
.photoWrapper img {
  width: 400px;
  height: 200px;
  margin-right:50px;
}
.el-button{
    margin-top:40px;
}
</style>
