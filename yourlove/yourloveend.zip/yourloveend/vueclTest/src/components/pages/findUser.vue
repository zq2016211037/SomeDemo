<template>
     <div class="searchUser">
        <p>Who do you want to Search?</p>
        <el-input placeholder="请输入内容" v-model="input5" class="input-with-select">
            <el-button slot="append" class="searchButton" icon="el-icon-search">搜索</el-button>
        </el-input>
        <p>total:5276 </p>
    </div>
</template>
<script>
export default {
    name:"findUser"
}
</script>
<style scoped>
.searchUser{
    width:400px;
    text-align: center;
    margin:0 auto;
    margin-top:200px;
}
.searchUser p{
    margin-top:10px;
    font-size:20px;
    color:rgb(74,140,255);
    font-family: Georgia, serif;
    text-shadow: 4px 4px 4px #cccccc;
}
</style>
