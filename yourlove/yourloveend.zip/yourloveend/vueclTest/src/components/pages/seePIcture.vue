<template>  
    <div>
        <p>首页</p>
        <scroll-picture />
        <p>其他</p>
        <div>
            <picture-item v-for="item in obj" :key="item.index" :obj="item" />    
        </div>
    </div>
</template>
<script>
import scrollPicture from '@/components/scrollPicture';
import pictureItem from '@/components/pictureItem';
export default {
    name:"seePicture",
    data(){
        return{
             obj:[
          {
            url:"https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100",
            title:"匿名聊天"
          },
          {
            url:"http://loveimg.lengren.com.cn/1535051919356",
            title:"匿名聊天"
          },
          {
            url:"https://fuss10.elemecdn.com/3/63/4e7f3a15429bfda99bce42a18cdd1jpeg.jpeg?imageMogr2/thumbnail/360x360/format/webp/quality/100",
            title:"匿名聊天"
          }
      ]
        }
    },
    components:{
        scrollPicture,
        pictureItem
    }
}
</script>
<style scoped>
p{
    display: block;
    font-size: 20px;
    border-bottom:1px solid #cccccc
}
</style>
