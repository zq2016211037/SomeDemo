<template>
<div>
    <h1>个人信息</h1>
    <user-info />
    <h1>Ta的关注</h1>
    <div class="users">
        <user-bar />
    </div>
    <h1>Ta的粉丝</h1>
    <div class="users">
        <user-bar/>
    </div>
    <h1>Ta的发布</h1>
    <publish-table/>
    <h1>Ta的评论</h1>
    <comment-table/>
</div>
</template>
<script>
import userInfo from '@/components/userInfo'
import publishTable from '@/components/publishTable'
import commentTable from '@/components/comment'
import userBar from '@/components/userBar'
export default {
    name:"userInformation",
    components:{
        userInfo,
        publishTable,
        commentTable,
        userBar
    }
}
</script>

<style scoped>
h1{
    font-size:20px;
    display:block;
    width: 100%;
    border-bottom:1px solid #cccccc;
    margin-top:20px;
    margin-bottom:30px;
}
.users{
    width: 100%;
    border-bottom:1px solid #cccccc;
    padding:10px 50px 10px 50px;
}
</style>
