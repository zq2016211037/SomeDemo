<template>
    <div>
        <article-type />
        <article-table />
        <change-page />
    </div>
</template>
<script>
import articleType from '@/components/articleType'
import articleTable from '@/components/articleTable'
import changePage from '@/components/changePage'
export default {
   name:"seeArticle",
   components:{
       articleType,
       articleTable,
       changePage
   } 
}
</script>
<style>
</style>
