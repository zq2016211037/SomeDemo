<template>
    <div class="wrapper">
        <h1>yourlove</h1>
        <my-canvas/>
        <enter-form/>
    </div>
</template>
<script>
import myCanvas from "@/components/canvas";
import enterForm from '@/components/enterForm';
export default {
   name:"enter",
   components:{
       myCanvas,
       enterForm
   }
}
</script>
<style scoped>
.wrapper{
    width:400px;
    margin:0 auto;
    margin-top: 150px;
}
h1{
    margin-left: 145px;
    color:rgb(0,134,255);
    font-weight: bolder;
    font-size: 45px;
    letter-spacing: 0.01em;
    font-family: Georgia, serif;
    text-shadow:3px 3px 3px #cccccc;
}
</style>
