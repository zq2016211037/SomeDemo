<template>
    <div>
        <p>添加账户</p>
        <add-user/>
        <p>查看账户</p>
        <user-table/>
    </div>
</template>
<script>
import addUser from "@/components/addUser";
import userTable from "@/components/userTable";
export default {
  name: "seeUser",
  components: {
    addUser,
    userTable,
  },
  data() {
    return {
      options: ["第一张", "第二张", "第三张"],
      options2: ["第0张后", "第1张后", "第2张厚"],
      value2:"",
      value1: "",
      fileList: [],
      input:"",
    };
  },
  methods:{
      handleRemove(file, fileList) {
        console.log(file, fileList);
      },
      handlePreview(file) {
        console.log(file);
      },
      handleExceed(files, fileList) {
        this.$message.warning(`当前限制选择 3 个文件，本次选择了 ${files.length} 个文件，共选择了 ${files.length + fileList.length} 个文件`);
      },
      beforeRemove(file, fileList) {
        return this.$confirm(`确定移除 ${ file.name }？`);
      }
  }
};
</script>
<style scoped>
p {
  display: block;
  width: 100%;
  border-bottom: 1px solid #cccccc;
  font-size: 20px;
}
</style>
