<template>
    <div class="wrapper">
        <img :src="info.avatarUrl"/>
        <span class="nickName">{{info.nickName}}</span>
        <div class="articleinfo">
            <p>发布时间：2018-8-10 17:08:08</p>
            <p>
                <span>
                    浏览量：566；
                </span>
                <span>
                    赞：221；
                </span>
                <span>
                    评论：221；
                </span>
            </p>
    </div>
    </div>
</template>
<script>
export default {
    name:"articleUser"
}
</script>
<style scoped>
.wrapper{
    display: flex;
}
img{
    width:80px;
    height:80px;
    border-radius: 50%;
    border:1px solid #cccccc;
    vertical-align: middle
}
.nickName{
    display: inline-block;
    vertical-align: middle;
    margin-left: 5px;
}
 p{
    font-size:13px;
}
.articleInfo span{
    margin-right:5px;
}
</style>
