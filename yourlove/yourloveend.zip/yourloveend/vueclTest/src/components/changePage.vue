<template> 
<div class="changePage">
  <el-button type="primary" icon="el-icon-arrow-left">上一页</el-button>
    <span class="pages">1/20页</span>
  <el-button type="primary">下一页<i class="el-icon-arrow-right el-icon--right"></i></el-button>
</div>
</template>
<script>
export default {
    name:"changePage"
}
</script>
<style>
    .changePage{
        width:400px;
        margin:0 auto;
        margin-top:20px;
    }
    .pages{
        color:rgb(29,151,255);
        padding-left:20px;
        padding-right: 20px;
    }
</style>
