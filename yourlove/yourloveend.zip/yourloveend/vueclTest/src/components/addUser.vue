<template>
<div>
<el-form ref="form" :model="form" label-width="80px" class="formWrapper">
  <el-form-item label="账号">
    <el-input v-model="form.number" style="width:400px;"></el-input>
  </el-form-item>
   <el-form-item label="姓名">
    <el-input v-model="form.name" style="width:400px;"></el-input>
  </el-form-item>
   <el-form-item label="密码">
    <el-input v-model="form.password" style="width:400px;"></el-input>
  </el-form-item>
   <el-form-item label="电话">
    <el-input v-model="form.phone" style="width:400px;"></el-input>
  </el-form-item>
   <el-form-item label="备注">
    <el-input v-model="form.more" style="width:400px;"></el-input>
  </el-form-item>
  <el-form-item>
        <el-checkbox :indeterminate="isIndeterminate" v-model="checkAll" @change="handleCheckAllChange">全选</el-checkbox>
        <div style="margin: 15px 0;"></div>
        <el-checkbox-group v-model="form.checkedPower" @change="handleCheckedPowerChange">
            <el-checkbox v-for="item in power" :label="item" :key="item">{{item}}</el-checkbox>
        </el-checkbox-group>
  </el-form-item>
  <el-form-item>
    <el-button type="primary">添加</el-button>
  </el-form-item>
</el-form>
</div>
</template>
<script>
const powerOptions =  ["更改图片","删除文章","删除评论","账号管理","使用小程序","发布招聘"];
export default {
    name:"addUser",
    data(){
        return{
            power:powerOptions,
            checkAll:false,
            isIndeterminate: true,
            form:{
                name:"",
                number:"",
                password:"",
                phone:"",
                more:"",
                checkedPower:[]
            }
        }
    },
    methods: {
      handleCheckAllChange(val) {
        this.form.checkedPower = val ? powerOptions : [];
        this.isIndeterminate = false;
      },
      handleCheckedPowerChange(value) {
        let checkedCount = value.length;
        this.checkAll = checkedCount === this.power.length;
        this.isIndeterminate = checkedCount > 0 && checkedCount < this.power.length;
      }
    }
}
</script>
<style scoped>
.formWrapper{
    display: flex;
    flex-wrap: wrap;
}
.el-input__inner{
    width:400px;
}
</style>
