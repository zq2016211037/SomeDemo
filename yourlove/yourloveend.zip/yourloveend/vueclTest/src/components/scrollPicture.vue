<template>
    <div>
        <div class="photoWrapper">
            <div class="block"> 
                <el-carousel trigger="click" height="150px">
                <el-carousel-item v-for="item in 4" :key="item">
                    <img src="http://loveimg.lengren.com.cn/1535051919356"/>
                </el-carousel-item>
                </el-carousel>
            </div>
            <div class="formWrapper">
            <el-form>
                <el-form-item>
                    <el-select v-model="value2" placeholder="请选择">
                        <el-option
                            v-for="item in options2"
                            :key="item.index"
                            :value="item">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item>
                    <el-upload  class="upload-demo"
  action="https://jsonplaceholder.typicode.com/posts/"
  :on-preview="handlePreview"
  :on-remove="handleRemove"
  :before-remove="beforeRemove"
  multiple
  :limit="3"
  :on-exceed="handleExceed"
  :file-list="fileList">
                            <el-button size="small" type="primary">点击上传</el-button>
                        </el-upload>
                </el-form-item>
                <el-form-item>
                    <el-input v-model="input" placeholder="请输入链接"></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" size="small">替换</el-button>
                </el-form-item>
            </el-form>
            <el-form>
             <el-form-item>
                    <el-select v-model="value1" placeholder="请选择">
                        <el-option
                            v-for="item in options"
                            :key="item.index"
                            :value="item">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" size="small">删除</el-button>
                </el-form-item>
            </el-form>
             <el-form>
                <el-form-item>
                    <el-select v-model="value1" placeholder="请选择">
                        <el-option
                            v-for="item in options"
                            :key="item.index"
                            :value="item">
                        </el-option>
                    </el-select>
                </el-form-item>
                <el-form-item>
                    <el-upload  class="upload-demo"
  action="https://jsonplaceholder.typicode.com/posts/"
  :on-preview="handlePreview"
  :on-remove="handleRemove"
  :before-remove="beforeRemove"
  multiple
  :limit="3"
  :on-exceed="handleExceed"
  :file-list="fileList">
                            <el-button size="small" type="primary">点击上传</el-button>
                        </el-upload>
                </el-form-item>
                <el-form-item>
                    <el-input v-model="input" placeholder="请输入链接"></el-input>
                </el-form-item>
                <el-form-item>
                    <el-button type="primary" size="small">替换</el-button>
                </el-form-item>
            </el-form>
        </div>  
        </div>
    </div> 
</template>
<script>
export default {
 name:"scrollPicture",
 data() {
    return {
      options: ["第一张", "第二张", "第三张"],
      options2: ["第0张后", "第1张后", "第2张厚"],
      value2:"",
      value1: "",
      fileList: [],
      input:"",
    };
  },
  methods:{
      handleRemove(file, fileList) {
        console.log(file, fileList);
      },
      handlePreview(file) {
        console.log(file);
      },
      handleExceed(files, fileList) {
        this.$message.warning(`当前限制选择 3 个文件，本次选择了 ${files.length} 个文件，共选择了 ${files.length + fileList.length} 个文件`);
      },
      beforeRemove(file, fileList) {
        return this.$confirm(`确定移除 ${ file.name }？`);
      }
  },
};
</script>
<style scoped>
.el-form{
    display: flex;
    width:700px;
}
.el-button{
    margin-left: 30px;
    margin-right:30px;
}
.el-carousel__item img {
  width: 400px;
  height: 250px;
}

.block {
  width: 450px;
  height: 300px;
}
.photoWrapper{
    display: flex;
}
</style>
