<template>
    <el-form :model="ruleForm" :rules="rules" ref="ruleForm" label-width="100px" class="demo-ruleForm">
        <el-form-item label="账号" prop="name">
            <el-input v-model="ruleForm.name"></el-input>
        </el-form-item>
        <el-form-item label="密码" prop="pass">
             <el-input type="password" v-model="ruleForm.pass" auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item>
            <el-button type="primary" @click="submitForm" class="form-button">登录</el-button>
            </el-form-item>
    </el-form>
</template>
<script>
export default {
    name:"EnterFrom",
    data(){
        return{
            ruleForm:{
                name:'',
                pass:''
            },
            rules:{
                name:[
                    {required:true,message: '请输入账号', trigger: 'blur'}
                ],
                pass:[
                    {required:true,message: '请输入密码', trigger: 'blur'}
                ]
            }
        }
    },
    methods:{
        submitForm:function(){
            this.$router.push({path: '/yourlove'})
        }
    }
}
</script>

<style scoped>
.demo-ruleForm{
    max-width: 400px;
    margin:0 auto;
}
.form-button{
    width:300px;
    margin:0 auto;
}
</style>
