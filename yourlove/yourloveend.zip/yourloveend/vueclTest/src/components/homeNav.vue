<template>
  <el-menu
      default-active="1"
      class="el-menu-vertical-demo">
      <router-link to="/yourlove">
      <el-menu-item index="1"> 
        <i class="el-icon-third-account"/>
        <span slot="title">查看用户</span>
      </el-menu-item>
      </router-link>
      <router-link to="/seeArticle">
       <el-menu-item index="2">
        <i class="el-icon-third-copy"></i>
        <span slot="title">文章管理</span>
      </el-menu-item>
      </router-link>
      <router-link to="/seePicture">
       <el-menu-item index="3">
        <i class="el-icon-third-pic-filling"></i>
        <span slot="title">图片管理</span>
      </el-menu-item>
      </router-link>
      <router-link to="/seeUser">
       <el-menu-item index="4">
        <i class="el-icon-third-qunzu"></i>
        <span slot="title">账户管理</span>
      </el-menu-item>
      </router-link>
      <el-menu-item index="5">
        <i class="el-icon-third-dianhua"></i>
        <span slot="title">举报管理</span>
      </el-menu-item>
    </el-menu>  
</template>
<script>
export default {
    name:"leftNav"
}
</script>
<style scoped>
.el-menu-vertical-demo{
  width:250px;
  border:none;
}
a{
  text-decoration: none;
}
</style>
