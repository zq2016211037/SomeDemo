<template>
<div>
<el-table
    :data="tableData"
    class="publish-table"
    style="padding:30px;">
    <el-table-column
      prop="title"
      label="标题"
      width="350">
    </el-table-column>
    <el-table-column
      prop="type"
      label="分类"
      width="80">
    </el-table-column>
    <el-table-column
      prop=“browseNumber”
      label="浏览量"
      width="100">
    </el-table-column>
    <el-table-column
      prop="admireNumber"
      label="点赞量"
      width="100">
    </el-table-column>
    <el-table-column
      prop="commentNumber"
      label="评论量"
      width="100">
    </el-table-column>
    <el-table-column
      prop="date"
      label="时间"
      width="180">
    </el-table-column>
    <el-table-column
      label="操作"
      width="80">
      <template slot-scope="scope">
        <el-button
          @click.native.prevent="deleteRow(scope.$index, tableData4)"
          type="text"
          size="small">
          移除
        </el-button>
      </template>
    </el-table-column>
</el-table>
<el-button type="primary" size="small" class="morebutton">更多</el-button>
</div>
</template>
<style>

</style>

<script>
export default {
    name:"publishTable",
    data(){
        return{
            tableData:[
                {
                    title:"我恨前端！哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈恨",
                    type:"表白",
                    browseNumber:"120",
                    admireNumber:"80",
                    commentNumber:"20",
                    date:"2018-7-9 13:59:59"
                },
                {
                    title:"我恨前端！",
                    type:"表白",
                    browseNumber:"120",
                    admireNumber:"80",
                    commentNumber:"20",
                    date:"2018-7-9 13:59:59"
                },{
                    title:"我恨前端！",
                    type:"表白",
                    browseNumber:"120",
                    admireNumber:"80",
                    commentNumber:"20",
                    date:"2018-7-9 13:59:59"
                },{
                    title:"我恨前端！",
                    type:"表白",
                    browseNumber:"120",
                    admireNumber:"80",
                    commentNumber:"20",
                    date:"2018-7-9 13:59:59"
                },{
                    title:"我恨前端！",
                    type:"表白",
                    browseNumber:"120",
                    admireNumber:"80",
                    commentNumber:"20",
                    date:"2018-7-9 13:59:59"
                }
            ]
        }
    }    
}
</script>
<style scoped>
    .morebutton{
        float:right;
        margin-right:120px;
    }
</style>

