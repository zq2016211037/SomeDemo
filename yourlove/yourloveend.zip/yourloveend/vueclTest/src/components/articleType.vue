<template>
<div>
<div class="allWrapper">
<div>
    <span>筛选条件：</span>
    <el-select v-model="value" placeholder="请选择">
    <el-option
      v-for="item in options"
      :key="item.index"
      :value="item">
    </el-option>
  </el-select>
</div>
<div>
   <span>排序条件：</span>
    <el-select v-model="value1" placeholder="请选择">
    <el-option
      v-for="item in options1"
      :key="item.index"
      :value="item">
    </el-option>
  </el-select>
</div>
<div class="searchWrapper">
    <el-input v-model="input" placeholder="请输入文章标题"></el-input>
    <el-button type="primary">查找</el-button>
</div>
</div>
</div>
</template>
<script>
import articleTable from '@/components/articleTable'
export default {
    name:'articleType',
    data(){
        return{
            options:[
                "全部",
                "邮所爱",
                "邮所值",
                "邮所得",
            ],
            options1:[
                "按时间排序",
                "按点赞量排序",
                "按评论量排序",
                "按浏览量排序"
            ],
            value:"",
            value1:""
        }
    },
    components:{
        articleTable
    }
}
</script>
<style scoped>
.allWrapper{
    display: flex;
    justify-content: space-around;
    width:1000px;
    height:40px;
}
span{
    color:rgb(147,147,154)
}
.searchWrapper{
    width:300px;
    display: flex;
    margin-left: 40px;
}
</style>
