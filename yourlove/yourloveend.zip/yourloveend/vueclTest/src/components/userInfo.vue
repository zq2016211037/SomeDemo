<template>
<div>
    <img :src="info.avatarUrl" />
    <table>
        <tr>
            <td>
                昵称：{{info.nickName}}
            </td>
            <td>
                签名：{{info.signature}}
            </td>
            <td>
                等级：{{info.rank}}
            </td>
        </tr>
        <tr>
            <td>
               年级：{{info.grade}}
            </td>
            <td>
                专业：{{info.majorName}}
            </td>
            <td>
                经验值：{{info.experience}}
            </td>
        </tr>
        <tr>
            <td>
              生日：{{info.birthday}}  
            </td>
            <td>
              邮箱：{{info.mail}}
            </td>
            <td>
              积分值：{{info.point}}
            </td>
        </tr>
    </table>
</div>
</template>
<script>
import userBar from './userBar';
import publishTable from './publishTable';
import commentTable from './comment'
export default {
    name:"userInfo",
    data(){
        return{
            info:{
                nickName:"杨小涵",
                signature:"啊哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈",
                point:"200",
                grade:2016,
                mail:"853654529@qq.com",
                majorName:"信息管理与信息系统",
                experience:"100",
                birthday:"1999-07-09",
                rank:"4",
                avatarUrl:"http://loveimg.lengren.com.cn/1535051919356"
            }
        }   
    },
    components:{
        userBar,
        publishTable,
        commentTable
    }

}
</script>
<style scoped>
table{
    padding:15px;
    margin:0 auto;
}
td{
    max-width: 400px;
    box-sizing: border-box;
    padding:8px 45px 8px 45px;
    letter-spacing: px;
    font-size:15px;
    color:rgb(0,0,0);
    font-weight: 300;
}
img{
    display: block;
    width:80px;
    height:80px;
    border-radius: 50%;
    margin:0 auto;
    border:1px solid #cccccc;
}
div{
    padding-top:30px;
    width:100%;
    border-bottom:1px solid #cccccc;
    
}
.el-table__body, .el-table__footer, .el-table__header{
    padding-bottom:30px;
}
</style>
