<template>
<div>
    <el-table
    :data="tableData1"
    style="width: 100%;padding:30px;">
    <el-table-column
      prop="date"
      label="日期"
      width="150">
    </el-table-column>
    <el-table-column
      prop="content"
      label="内容"
      width="400">
    </el-table-column>
    <el-table-column
      prop="title"
      label="标题"
      width="280">
    </el-table-column>
    <el-table-column
      prop="admireNumber"
      label="点赞量"
      width="80">
    </el-table-column>
    <el-table-column
      label="操作"
      width="120">
      <template slot-scope="scope">
        <el-button
          @click.native.prevent="deleteRow(scope.$index, tableData4)"
          type="text"
          size="small">
          移除
        </el-button>
      </template>
    </el-table-column>
  </el-table>
  <el-button type="primary" size="small" class="morebutton">更多</el-button>
</div>
</template>
<script>
export default {
    data(){
        return{
            tableData1:[
                {
                    title:"哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈",
                    content:"哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈杨雨涵大美女大美女大美女大美女大美女",
                    admireNumber:"220",
                    date:"2018-05-09 15:38:38"
                },{
                    title:"哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈",
                    content:"哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈杨雨涵大美女大美女大美女大美女大美女",
                    admireNumber:"220",
                    date:"2018-05-09 15:38:38"
                },{
                    title:"哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈",
                    content:"哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈杨雨涵大美女大美女大美女大美女大美女",
                    admireNumber:"220",
                    date:"2018-05-09 15:38:38"
                },{
                    title:"哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈",
                    content:"哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈杨雨涵大美女大美女大美女大美女大美女",
                    admireNumber:"220",
                    date:"2018-05-09 15:38:38"
                },{
                    title:"哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈",
                    content:"哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈杨雨涵大美女大美女大美女大美女大美女",
                    admireNumber:"220",
                    date:"2018-05-09 15:38:38"
                },{
                    title:"哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈",
                    content:"哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈杨雨涵大美女大美女大美女大美女大美女",
                    admireNumber:"220",
                    date:"2018-05-09 15:38:38"
                },{
                    title:"哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈",
                    content:"哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈哈杨雨涵大美女大美女大美女大美女大美女",
                    admireNumber:"220",
                    date:"2018-05-09 15:38:38"
                },
            ]
        }
    }
}
</script>
<style scoped>
.morebutton{
        float:right;
        margin-right:120px;
    }
</style>

